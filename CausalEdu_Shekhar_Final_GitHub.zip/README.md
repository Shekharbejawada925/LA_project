# CausalEdu Learning Analytics — Research Project

**Author and repository maintainer: Bejawada Shekhar (26m1032)**  
**IIT Bombay · ET601 · 2026**

This package includes the revised academic PDF, a portfolio executive summary PDF, project source scripts, and four original report figures.

## Hypotheses

- **H1:** Observational check-in/check-out estimates exceed randomized ATEs. Supported as a descriptive gap; the estimands differ.
- **H2:** Guessing correction and prediction models improve ATE estimation. Partially supported: gradient boosting lowers RMSE but does not clearly outperform the mean-ATE baseline.
- **H3:** Gaps depend on year and prerequisite proximity. Partially supported: year-group association is evident, prerequisite distance is not.

## Project structure

- `final_report.pdf`: revised academic report, with user-declared sole authorship
- `portfolio_report.pdf`: executive overview and revised report
- `code/analysis.py`: analysis and visualizations
- `code/build_report.py`: updated report generator
- `figures/`: four figures extracted from the submitted report

## Run

Install `pip install -r requirements.txt`, download public [Eedi CausalEdu](https://github.com/Eedi/CausalEdu) CSV files into `data/`, and run `python -I code/analysis.py data .` followed by `python -I code/build_report.py .`. The dataset is not distributed here.

**Revision note:** This version reflects the user's explicit declaration of sole authorship. Prior submitted versions have separate provenance.
